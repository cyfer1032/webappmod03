package mod03;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class GetURLRewritingCounter
 */
@WebServlet("/geturlrewritingcounter")
public class GetURLRewritingCounter extends HttpServlet {
  private static final long serialVersionUID = 1L;

  public void doGet(HttpServletRequest req, HttpServletResponse res)
      throws ServletException, IOException {

    String message = null;
    Integer counter = null;

    // セッション・オブジェクトの取得
    HttpSession session = req.getSession(false);

    // セッション・オブジェクトの取得確認
    // 取得できない場合は作成し、カウンタを用意する
    if (session == null) {
      session = req.getSession(true);
      message = "This is the first access";
      counter = new Integer(0);

      // 取得できた場合はカウンタを取り出す
    } else {
      message = "Welcome again";
      counter = (Integer) session.getAttribute("counter");
    }

    // カウンタを 1 増加し、セッション・オブジェクトに保存する
    counter++;
    session.setAttribute("counter", counter);

    res.setContentType("text/html; charset=UTF-8");
    PrintWriter out = res.getWriter();
    out.println("<html>");
    out.println("<head>");
    out.println("<title>Get URLRewriting Counter</title>");
    out.println("</head>");
    out.println("<body>");
    out.println("<h1>Get URLRewriting Counter</h1>");
    out.println("<br><hr><br>");

    // セッション・オブジェクトに格納した文字列を出力
    out.println("<h2><font size=\"5\">" + message + "</font></h2>");

    // セッション・オブジェクトに格納したカウンタを出力
    out.println("<p>You have hit this page " + counter
        + " times</p>");

    // URL Rewriting を使用して、URL にセッション ID を埋め込む
    out.println("<a href=" + res.encodeURL(
        "/examples/geturlrewritingcounter") + ">click</a>");

    out.println("</body>");
    out.println("</html>");
  }
}
